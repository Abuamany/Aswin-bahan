
setwd("D:/2016/uii/file_latihan")

